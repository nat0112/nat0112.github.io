# Fish Farm Pro - Android Build Instructions

## วิธีที่ 1: PWA (Progressive Web App) - ง่ายและเร็ว

### ขั้นตอนการติดตั้ง PWA บน Android

1. **เปิด Chrome บนมือถือ Android**

2. **เข้าเว็บแอพ** (ต้อง host บน HTTPS)
   - ใช้ GitHub Pages, Netlify, Vercel หรือ Firebase Hosting

3. **ติดตั้งแอพ**
   - กดปุ่ม ⋮ (เมนู 3 จุด) มุมขวาบน
   - เลือก "Add to Home Screen" หรือ "ติดตั้งแอป"
   - กด "Install" หรือ "ติดตั้ง"

4. **เสร็จสิ้น!** - แอพจะปรากฏบนหน้าจอหลักเหมือนแอพปกติ

### การ Host PWA ฟรี

#### GitHub Pages:
```bash
# สร้าง repository บน GitHub
# อัพโหลดไฟล์ทั้งหมดใน fish-farm-app/
# ไปที่ Settings > Pages > เลือก main branch
# เว็บจะอยู่ที่: https://username.github.io/repo-name/
```

#### Netlify:
1. ลงทะเบียนที่ https://netlify.com
2. ลากโฟลเดอร์ fish-farm-app/ ไปวาง
3. รอสักครู่ จะได้ URL อัตโนมัติ

---

## วิธีที่ 2: Capacitor - สร้าง APK

### ข้อกำหนดเบื้องต้น

1. **Node.js** (v18+): https://nodejs.org
2. **Android Studio**: https://developer.android.com/studio
3. **Java JDK 17+**: https://adoptium.net

### ขั้นตอนการ Build

#### 1. ติดตั้ง Dependencies

```bash
cd fish-farm-mobile
npm install
```

#### 2. เพิ่ม Android Platform

```bash
npx cap add android
```

#### 3. Sync โปรเจค

```bash
npx cap sync
```

#### 4. เปิดใน Android Studio

```bash
npx cap open android
```

#### 5. Build APK

**ใน Android Studio:**
1. รอให้ Gradle sync เสร็จ
2. ไปที่ Build > Build Bundle(s) / APK(s) > Build APK(s)
3. รอ build เสร็จ
4. ไฟล์ APK จะอยู่ที่: `android/app/build/outputs/apk/debug/app-debug.apk`

**หรือใช้ Command Line:**
```bash
cd android
./gradlew assembleDebug
```

### การสร้าง Release APK (สำหรับเผยแพร่)

#### 1. สร้าง Keystore

```bash
keytool -genkey -v -keystore fish-farm-release.keystore -alias fishfarm -keyalg RSA -keysize 2048 -validity 10000
```

#### 2. สร้างไฟล์ signing config

สร้างไฟล์ `android/keystore.properties`:
```properties
storePassword=YOUR_STORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=fishfarm
storeFile=../fish-farm-release.keystore
```

#### 3. Build Release APK

```bash
cd android
./gradlew assembleRelease
```

ไฟล์จะอยู่ที่: `android/app/build/outputs/apk/release/app-release.apk`

---

## โครงสร้างโปรเจค

```
fish-farm-mobile/
├── package.json          # Dependencies และ Scripts
├── capacitor.config.json # Capacitor Configuration
├── www/                  # Web App Files
│   ├── index.html
│   ├── manifest.json
│   ├── service-worker.js
│   └── icons/
│       └── icon.svg
└── android/              # Android Project (สร้างหลัง cap add android)
    ├── app/
    │   └── src/
    └── ...
```

---

## การอัพเดตแอพ

เมื่อแก้ไขไฟล์ใน `www/`:

```bash
# Sync การเปลี่ยนแปลง
npx cap sync

# หรือ copy ไฟล์ใหม่
npx cap copy
```

---

## การตั้งค่า Icon และ Splash Screen

### App Icon
แทนที่ไฟล์ใน `android/app/src/main/res/`:
- `mipmap-mdpi/ic_launcher.png` (48x48)
- `mipmap-hdpi/ic_launcher.png` (72x72)
- `mipmap-xhdpi/ic_launcher.png` (96x96)
- `mipmap-xxhdpi/ic_launcher.png` (144x144)
- `mipmap-xxxhdpi/ic_launcher.png` (192x192)

### Splash Screen
แทนที่ไฟล์ใน `android/app/src/main/res/drawable/`:
- `splash.png`

---

## Troubleshooting

### ปัญหา: Gradle Build Failed
```bash
cd android
./gradlew clean
./gradlew assembleDebug
```

### ปัญหา: SDK not found
- เปิด Android Studio > SDK Manager
- ติดตั้ง Android SDK Platform 33+

### ปัญหา: Java version
- ตรวจสอบ Java version: `java -version`
- ต้องใช้ Java 17+

---

## คำสั่งที่ใช้บ่อย

| คำสั่ง | คำอธิบาย |
|--------|----------|
| `npm run cap:sync` | Sync web files กับ Android |
| `npm run cap:open:android` | เปิด Android Studio |
| `npx cap run android` | รัน app บน emulator/device |
| `npx cap build android` | Build production |

---

## ติดต่อ

หากมีปัญหาหรือต้องการความช่วยเหลือ สามารถสร้าง Issue ได้
