# 🐟 Fish Farm Pro - คู่มือตั้งค่า Firebase Cloud Sync

## ภาพรวม

เอกสารนี้อธิบายวิธีการตั้งค่า Firebase Realtime Database เพื่อให้แอพ Fish Farm Pro สามารถ sync ข้อมูลข้ามอุปกรณ์ได้

## ขั้นตอนการตั้งค่า Firebase (ฟรี)

### 1. สร้าง Firebase Project

1. ไปที่ [Firebase Console](https://console.firebase.google.com)
2. คลิก **"Create a project"** หรือ **"Add project"**
3. ตั้งชื่อโปรเจค เช่น "fish-farm-pro"
4. ปิด Google Analytics ได้ (ไม่จำเป็น)
5. คลิก **"Create project"**

### 2. สร้าง Realtime Database

1. ในเมนูซ้าย เลือก **Build** → **Realtime Database**
2. คลิก **"Create Database"**
3. เลือก location ที่ใกล้ที่สุด (แนะนำ Singapore)
4. **สำคัญ:** เลือก **"Start in test mode"**
5. คลิก **"Enable"**

### 3. ตั้งค่า Security Rules (สำหรับทีมเล็ก)

ไปที่ **Realtime Database** → **Rules** แล้วเปลี่ยนเป็น:

```json
{
  "rules": {
    ".read": true,
    ".write": true
  }
}
```

> ⚠️ **หมายเหตุ:** Rules นี้เปิดให้ทุกคนอ่าน/เขียนได้ เหมาะสำหรับทีมเล็กที่ไว้ใจกัน หากต้องการความปลอดภัยสูงกว่านี้ ให้ใช้ Firebase Authentication

### 4. สร้าง Web App และ Copy Config

1. ไปที่ **Project Settings** (ไอคอนเกียร์ ⚙️)
2. เลื่อนลงไปที่ **"Your apps"**
3. คลิก **Web icon** `</>`
4. ตั้งชื่อแอพ เช่น "Fish Farm Web"
5. **ไม่ต้อง** เลือก Firebase Hosting
6. คลิก **"Register app"**
7. Copy ส่วน `firebaseConfig`:

```javascript
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "xxx.firebaseapp.com",
  databaseURL: "https://xxx-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "xxx",
  storageBucket: "xxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

### 5. ใส่ Config ในแอพ

เปิดแอพ Fish Farm Pro แล้ว:
1. วาง JSON config ที่ copy มาลงในช่อง
2. หรือกรอกแยกทีละช่อง:
   - **API Key**: ค่า apiKey
   - **Database URL**: ค่า databaseURL
   - **Project ID**: ค่า projectId
3. คลิก **"บันทึกและเชื่อมต่อ"**

---

## การทำงานของระบบ Sync

### Realtime Sync
- เมื่อผู้ใช้คนหนึ่งบันทึกข้อมูล ข้อมูลจะถูกส่งไป Firebase ทันที
- อุปกรณ์อื่นๆ ที่ออนไลน์อยู่จะได้รับข้อมูลใหม่โดยอัตโนมัติ

### Offline Support
- ข้อมูลจะถูกเก็บใน localStorage ด้วย
- เมื่อออฟไลน์ แอพยังใช้งานได้ตามปกติ
- เมื่อกลับมาออนไลน์ ข้อมูลจะ sync อัตโนมัติ

### ข้อควรระวัง
- ถ้า 2 คนแก้ไขข้อมูลเดียวกันพร้อมกัน คนที่บันทึกทีหลังจะ overwrite
- แนะนำให้แบ่งหน้าที่ชัดเจน เช่น คนละบ่อ

---

## Quota ฟรีของ Firebase

Firebase Spark Plan (ฟรี):
- **Simultaneous connections**: 100
- **GB stored**: 1 GB
- **GB downloaded**: 10 GB/month

สำหรับฟาร์มขนาดเล็ก (ไม่เกิน 5 คน) เพียงพออย่างแน่นอน!

---

## Troubleshooting

### "Permission denied" error
- ตรวจสอบว่าตั้ง Security Rules เป็น test mode แล้ว
- ตรวจสอบว่า Database URL ถูกต้อง

### ไม่เห็นสถานะ "Online"
- ตรวจสอบการเชื่อมต่ออินเทอร์เน็ต
- ลอง refresh หน้าเว็บ
- ตรวจสอบว่า config ถูกต้อง

### ข้อมูลไม่ sync
- ตรวจสอบว่าอุปกรณ์ทั้งหมดใช้ Firebase project เดียวกัน
- ลอง clear cache และ reload

---

## รีเซ็ตการตั้งค่า

หากต้องการเปลี่ยน Firebase project:
1. ไปที่ **ตั้งค่า** → **Cloud Sync**
2. คลิก **"รีเซ็ตการตั้งค่า Firebase"**
3. ใส่ config ใหม่
